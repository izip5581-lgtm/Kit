<?php

namespace Sasha\Kit\Menus;

use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use jojoe77777\FormAPI\SimpleForm;
use Sasha\Kit\Menus\KitStartMenu;
use Sasha\Kit\Menus\KitBaronMenu;
use Sasha\Kit\Menus\KitAspidMenu;
use Sasha\Kit\Menus\KitTitanMenu;
use Sasha\Kit\Menus\KitKnyazMenu;

class MainMenu {
    private PluginBase $plugin;
    private KitStartMenu $kitStartMenu;
    private KitBaronMenu $kitBaronMenu;
    private KitAspidMenu $kitAspidMenu;
    private KitTitanMenu $kitTitanMenu;
    private KitKnyazMenu $kitKnyazMenu;

    public function __construct(PluginBase $plugin) {
        $this->plugin = $plugin;
        $this->kitStartMenu = new KitStartMenu($plugin);
        $this->kitBaronMenu = new KitBaronMenu($plugin);
        $this->kitAspidMenu = new KitAspidMenu($plugin);
        $this->kitTitanMenu = new KitTitanMenu($plugin);
        $this->kitKnyazMenu = new KitKnyazMenu($plugin);

    }
    public function openKitMenu(Player $player):void {
        $form = new SimpleForm(function(Player $player, ?int $data) {
            if($data === null) return;
            switch($data) {
                case 0:
                    $this->kitStartMenu->openUnderMenuKitStart($player);
                    break;
                case 1:
                    $this->kitBaronMenu->openUnderMenuKitBaron($player);
                    break;
                case 2:
                    $this->kitAspidMenu->openUnderMenuKitAspid($player);
                    break;
                case 3:
                    $this->kitTitanMenu->openUnderMenuKitTitan($player);
                    break;
                case 4:
                    $this->kitKnyazMenu->openUnderMenuKitKnyaz($player);
                    break;
                
            }


        });
        $form->setTitle("KIT меню");
        $form->addButton("Kit Start");
        $form->addButton("Kit Барона");
        $form->addButton("Kit Aспида");
        $form->addButton("Kit Титана");
        $form->addButton("Kit Kнязь");
        $player->sendForm($form);
    }

}