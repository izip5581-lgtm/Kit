<?php

namespace Sasha\Kit\Menus;

use Sasha\Kit\Buttons\KitKnyaz\GiveKitKnyaz;
use Sasha\Kit\Buttons\KitKnyaz\InfoKitKnyaz;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use jojoe77777\FormAPI\SimpleForm;

class KitKnyazMenu {
    private PluginBase $plugin;
    private GiveKitKnyaz $giveKitKnyaz;
    private InfoKitKnyaz $infoKitKnyaz;

    public function __construct(PluginBase $plugin) {
        $this->plugin = $plugin;
        $this->giveKitKnyaz = new GiveKitKnyaz($plugin);
        $this->infoKitKnyaz = new InfoKitKnyaz($plugin);
    }

    public function openUnderMenuKitKnyaz(Player $player): void {
        $form = new SimpleForm(function(Player $player, ?int $data): void {
            if($data === null) return;

            switch($data) {
                case 0:
                    $this->giveKitKnyaz->giveKitKnyaz($player);
                    break;
                case 1:
                    $this->infoKitKnyaz->infoKitKnyaz($player);
                    break;
            }
        });
        
        $form->setTitle("§l§5Kit Князя");
        $form->addButton("§5Получить набор");
        $form->addButton("§dПосмотреть содержимое");
        
        $player->sendForm($form);
    }
}