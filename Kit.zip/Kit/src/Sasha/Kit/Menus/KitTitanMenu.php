<?php

namespace Sasha\Kit\Menus;

use Sasha\Kit\Buttons\KitTitan\GiveKitTitan;
use Sasha\Kit\Buttons\KitTitan\InfoKitTitan;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use jojoe77777\FormAPI\SimpleForm;

class KitTitanMenu {
    private PluginBase $plugin;
    private GiveKitTitan $giveKitTitan;
    private InfoKitTitan $infoKitTitan;

    public function __construct(PluginBase $plugin) {
        $this->plugin = $plugin;
        $this->giveKitTitan = new GiveKitTitan($plugin);
        $this->infoKitTitan = new InfoKitTitan($plugin);
    }

    public function openUnderMenuKitTitan(Player $player): void {
        $form = new SimpleForm(function(Player $player, ?int $data): void {
            if($data === null) return;

            switch($data) {
                case 0:
                    $this->giveKitTitan->giveKitTitan($player);
                    break;
                case 1:
                    $this->infoKitTitan->infoKitTitan($player);
                    break;
            }
        });
        
        $form->setTitle("Kit Titan");
        $form->addButton("Получить набор");
        $form->addButton("Посмотреть содержимое");
        
        $player->sendForm($form);
    }
}