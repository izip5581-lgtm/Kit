<?php

namespace Sasha\Kit\Menus;

use Sasha\Kit\Buttons\KitBaron\GiveBaronKit;
use Sasha\Kit\Buttons\KitBaron\InfoBaronKit;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use jojoe77777\FormAPI\SimpleForm;

class KitBaronMenu {
    private PluginBase $plugin;
    private GiveBaronKit $giveBaronKit;
    private InfoBaronKit $infoBaronKit;

    public function __construct(PluginBase $plugin) {
        $this->plugin = $plugin;
        $this->giveBaronKit = new GiveBaronKit($plugin);
        $this->infoBaronKit = new InfoBaronKit($plugin);
    }
    public function openUnderMenuKitBaron(Player $player):void {
        $form = new SimpleForm(function(Player $player, ?int $data):void {
            if($data === null) return;
                switch($data) {
                    case 0:
                        $this->giveBaronKit->giveBaronKit($player);
                        break;
                    case 1:
                        $this->infoBaronKit->infoBaronKit($player);
                        break;
                }
        });
        $form->setTitle("Baron Kit");
        $form->addButton("получить набор(раз в 1 день)");
        $form->addButton("посмотреть содержимое");
    }
}