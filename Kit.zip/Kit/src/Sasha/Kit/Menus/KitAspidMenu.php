<?php

namespace Sasha\Kit\Menus;

use Sasha\Kit\Buttons\KitAspid\GiveKitAspid;
use Sasha\Kit\Buttons\KitAspid\InfoKitAspid;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use jojoe77777\FormAPI\SimpleForm;

class KitAspidMenu {
    private PluginBase $plugin;
    private GiveKitAspid $giveKitAspid;
    private InfoKitAspid $infoKitAspid;

    public function __construct(PluginBase $plugin) { 
        $this->plugin = $plugin;
        $this->giveKitAspid = new GiveKitAspid($plugin);
        $this->infoKitAspid = new InfoKitAspid($plugin); 
    }

    // Добавьте метод для открытия меню
    public function openUnderMenuKitAspid(Player $player): void {
        $form = new SimpleForm(function(Player $player, ?int $data): void {
            if($data === null) return;

            switch($data) {
                case 0:
                    $this->giveKitAspid->giveKitAspid($player);
                    break;
                case 1:
                    $this->infoKitAspid->infoKitAspid($player);
                    break;
            }
        });
        
        $form->setTitle("Kit Aspid");
        $form->addButton("Получить набор(раз в 2 дня)");
        $form->addButton("Посмотреть содержимое");
        
        $player->sendForm($form);
    }
}