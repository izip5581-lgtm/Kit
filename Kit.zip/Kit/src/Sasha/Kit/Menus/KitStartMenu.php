<?php

namespace Sasha\Kit\Menus;

use Sasha\Kit\Buttons\KitStart\GiveKitStart;
use Sasha\Kit\Buttons\KitStart\InfoKitStart;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use jojoe77777\FormAPI\SimpleForm;
class KitStartMenu {
    private PluginBase $plugin;
    private GiveKitStart $giveKitStart;
    private InfoKitStart $infoKitStart;
  
    public function __construct(PluginBase $plugin) {
        $this->plugin = $plugin;
        $this->giveKitStart = new GiveKitStart($plugin);
        $this->infoKitStart = new InfoKitStart($plugin);
     
    }
    public function openUnderMenuKitStart(Player $player):void {
        $form = new SimpleForm(function(Player $player, ?int $data):void {
            if($data === null) return;
                switch($data) {
                    case 0:
                        $this->giveKitStart->giveKitStart($player);
                        break;
                    case 1:
                        $this->infoKitStart->infoKitStart($player);
                        break;
                    
                }
        });
        $form->setTitle("Kit start");
        $form->addButton("получить набор(раз в 1 день)");
        $form->addButton("посмотреть содержимое");
        $player->sendForm($form);

    }
}