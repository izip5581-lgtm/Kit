<?php

namespace Sasha\Kit;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use Sasha\Kit\Menus\MainMenu;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;


class Main extends PluginBase implements Listener {
    
    private MainMenu $mainMenu;
    
    public function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->mainMenu = new MainMenu($this);
        

        $this->getLogger()->info("[Kit] enabled");
    }
    
    public function onDisable(): void {
        $this->getLogger()->info("[Kit] disabled");
    }
    
    public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args): bool {
        if($cmd->getName() == "kit") {
            if($sender instanceof Player) {
                $this->mainMenu->openKitMenu($sender);
                return true;
            }
        }
        return false;
    }
}