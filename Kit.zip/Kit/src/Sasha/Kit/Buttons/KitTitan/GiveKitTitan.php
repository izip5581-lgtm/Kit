<?php

namespace Sasha\Kit\Buttons\KitTitan;

use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\item\VanillaItems;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;

class GiveKitTitan {
    private array $cooldownsKitTitan = [];
    private PluginBase $plugin;
    
    public function __construct(PluginBase $plugin) {
        $this->plugin = $plugin;
    }

    public function giveKitTitan(Player $player): void {
        $playerName = $player->getName();
        $currentTime = time();

       
        if(isset($this->cooldownsKitTitan[$playerName]) && ($currentTime - $this->cooldownsKitTitan[$playerName]) < 259200) {
            $remaining = 259200 - ($currentTime - $this->cooldownsKitTitan[$playerName]);
            $player->sendMessage("Подождите еще " . gmdate("H:i:s", $remaining) . " перед получением набора снова.");
            return;
        }

      
        $helmet = VanillaItems::NETHERITE_HELMET();
        $chestplate = VanillaItems::NETHERITE_CHESTPLATE();
        $leggings = VanillaItems::NETHERITE_LEGGINGS();
        $boots = VanillaItems::NETHERITE_BOOTS();

        
        $sword = VanillaItems::NETHERITE_SWORD();
        $arrow = VanillaItems::ARROW();

        
        $pickaxe = VanillaItems::NETHERITE_PICKAXE();
        $axe = VanillaItems::NETHERITE_AXE();
        $shovel = VanillaItems::NETHERITE_SHOVEL();

        
        $gapple = VanillaItems::GOLDEN_APPLE();
        $pearl = VanillaItems::ENDER_PEARL();
        $totem = VanillaItems::TOTEM();
        $exp = VanillaItems::EXPERIENCE_BOTTLE();
        $porkchop = VanillaItems::COOKED_PORKCHOP();
        $shulker = VanillaBlocks::SHULKER_BOX()->asItem(); 
        $chorus = VanillaItems::CHORUS_FRUIT(); 

       
        $gapple->setCount(12);
        $pearl->setCount(8);
        $totem->setCount(2);
        $exp->setCount(64);
        $porkchop->setCount(32);
        $arrow->setCount(32);
        $chorus->setCount(6);

        
        $protection4 = new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4);
        $protection3 = new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3);

        $helmet->addEnchantment($protection4);
        $chestplate->addEnchantment($protection4);
        $leggings->addEnchantment($protection3);
        $boots->addEnchantment($protection3);

        
        $sharpness5 = new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 5);
        $sword->addEnchantment($sharpness5);

       
        $efficiency4 = new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 4);
        $unbreaking3 = new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3);

        $pickaxe->addEnchantment($efficiency4);
        $pickaxe->addEnchantment($unbreaking3);
        
        $axe->addEnchantment($efficiency4);
        $axe->addEnchantment($unbreaking3);
        
        $shovel->addEnchantment($efficiency4);
        $shovel->addEnchantment($unbreaking3);

        
        

      
        $player->getInventory()->addItem(
            $helmet, $chestplate, $leggings, $boots, $sword,
            $arrow,
            $pickaxe, $axe, $shovel,
            $gapple, $pearl, $totem, $exp, $porkchop,
            $shulker, $chorus
        );

        
        $this->cooldownsKitTitan[$playerName] = $currentTime;
        
    }
}