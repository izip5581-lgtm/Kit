<?php

namespace Sasha\Kit\Buttons\KitTitan;

use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use jojoe77777\FormAPI\SimpleForm;

class InfoKitTitan {
    private PluginBase $plugin;

    public function __construct(PluginBase $plugin) {
        $this->plugin = $plugin;
    }

    public function infoKitTitan(Player $player): void {
        $helmet = VanillaItems::NETHERITE_HELMET();
        $chestplate = VanillaItems::NETHERITE_CHESTPLATE();
        $leggings = VanillaItems::NETHERITE_LEGGINGS();
        $boots = VanillaItems::NETHERITE_BOOTS();

        
        $sword = VanillaItems::NETHERITE_SWORD();
        $arrow = VanillaItems::ARROW();

        
        $pickaxe = VanillaItems::NETHERITE_PICKAXE();
        $axe = VanillaItems::NETHERITE_AXE();
        $shovel = VanillaItems::NETHERITE_SHOVEL();

        
        $gapple = VanillaItems::GOLDEN_APPLE();
        $pearl = VanillaItems::ENDER_PEARL();
        $totem = VanillaItems::TOTEM();
        $exp = VanillaItems::EXPERIENCE_BOTTLE();
        $porkchop = VanillaItems::COOKED_PORKCHOP();
        $shulker = VanillaBlocks::SHULKER_BOX()->asItem(); 
        $chorus = VanillaItems::CHORUS_FRUIT(); 

       
        $gapple->setCount(12);
        $pearl->setCount(8);
        $totem->setCount(2);
        $exp->setCount(64);
        $porkchop->setCount(32);
        $arrow->setCount(32);
        $chorus->setCount(6);

        
        $protection4 = new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4);
        $protection3 = new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3);

        $helmet->addEnchantment($protection4);
        $chestplate->addEnchantment($protection4);
        $leggings->addEnchantment($protection3);
        $boots->addEnchantment($protection3);

        
        $sharpness5 = new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 5);
        $sword->addEnchantment($sharpness5);

       
        $efficiency4 = new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 4);
        $unbreaking3 = new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3);

        $pickaxe->addEnchantment($efficiency4);
        $pickaxe->addEnchantment($unbreaking3);
        
        $axe->addEnchantment($efficiency4);
        $axe->addEnchantment($unbreaking3);
        
        $shovel->addEnchantment($efficiency4);
        $shovel->addEnchantment($unbreaking3);


       $menu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
       $inventory = $menu->getInventory();
       $menu->setName("Содержимое кита Аспида");
       $inventory->setItem(0, $helmet);
       $inventory->setItem(1, $chestplate);
       $inventory->setItem(3, $sword);
       $inventory->setItem(4, $pickaxe);
       $inventory->setItem(5, $axe);
       $inventory->setItem(6, $shovel);
       $inventory->setItem(8, $totem);
       $inventory->setItem(9, $leggings);
       $inventory->setItem(10, $boots);
       $inventory->setItem(12, $gapple);
       $inventory->setItem(13, $pearl);
       $inventory->setItem(14, $porkchop);
       $inventory->setItem(15, $chorus);
       $inventory->setItem(21, $exp);
       $inventory->setItem(22, $arrow);
       $inventory->setItem(26, $helmet);

       $glass = VanillaBlocks::STAINED_GLASS_PANE();

       for($i = 0; $i <= 26; $i++) {
            if($inventory->getItem($i)->isNull()) {
                $inventory->setItem($i, $glass);
            }
       }
       $menu->setListener(InvMenu::readonly());
       $menu->send($player);
    }
}