<?php

namespace Sasha\Kit\Buttons\KitAspid;

use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use jojoe77777\FormAPI\SimpleForm;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\InvMenuHandler;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\item\VanillaItems;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;

class InfoKitAspid {
    private PluginBase $plugin;

    public function __construct(PluginBase $plugin) {
        $this->plugin = $plugin;
    }

    public function infoKitAspid(Player $player): void {
        $helmet = VanillaItems::DIAMOND_HELMET();
        $chestplate = VanillaItems::DIAMOND_CHESTPLATE();
        $leggings = VanillaItems::DIAMOND_LEGGINGS();
        $boots = VanillaItems::DIAMOND_BOOTS();
        $sword = VanillaItems::DIAMOND_SWORD();
        $gapple = VanillaItems::GOLDEN_APPLE();
        $pearl = VanillaItems::ENDER_PEARL();
        $totem = VanillaItems::TOTEM();
        $pickaxe = VanillaItems::DIAMOND_PICKAXE();
        $axe = VanillaItems::DIAMOND_AXE();
        $shovel = VanillaItems::DIAMOND_SHOVEL();
        $chicken = VanillaItems::COOKED_CHICKEN();
        $exp = VanillaItems::EXPERIENCE_BOTTLE();
        $bow = VanillaItems::BOW();
        $arrow = VanillaItems::ARROW();
    

        $gapple->setCount(3);
        $pearl->setCount(2);
        $chicken->setCount(16);
        $exp->setCount(32);
        $arrow->setCount(16);

        $protection3 = new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3);
        $protection2 = new EnchantmentInstance(VanillaEnchantments::PROTECTION(),2);
        $effectivnost1 = new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(),1);

        $helmet->addEnchantment($protection3);
        $chestplate->addEnchantment($protection3);
        $leggings->addEnchantment($protection2);
        $boots->addEnchantment($protection2);

        $pickaxe->addEnchantment($effectivnost1);
        $axe->addEnchantment($effectivnost1);
        $shovel->addEnchantment($effectivnost1);
        
        
       $menu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
       $inventory = $menu->getInventory();
       $menu->setName("Содержимое кита Аспида");
       $inventory->setItem(0, $helmet);
       $inventory->setItem(1, $chestplate);
       $inventory->setItem(3, $sword);
       $inventory->setItem(4, $pickaxe);
       $inventory->setItem(5, $axe);
       $inventory->setItem(6, $shovel);
       $inventory->setItem(8, $totem);
       $inventory->setItem(9, $leggings);
       $inventory->setItem(10, $boots);
       $inventory->setItem(12, $exp);
       $inventory->setItem(13, $chicken);
       $inventory->setItem(14, $bow);
       $inventory->setItem(15, $arrow);
       $inventory->setItem(21, $gapple);
       $inventory->setItem(22, $pearl);


       $glass = VanillaBlocks::STAINED_GLASS_PANE();

       for($i = 0; $i <= 26; $i++) {
            if($inventory->getItem($i)->isNull()) {
                $inventory->setItem($i, $glass);
            }
       }
       $menu->setListener(InvMenu::readonly());
       $menu->send($player);

    }
}