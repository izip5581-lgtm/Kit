<?php

namespace Sasha\Kit\Buttons\KitAspid;

use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\item\VanillaItems;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;

class GiveKitAspid {
    private array $cooldownsKitAspid = [];
    private PluginBase $plugin;
    
    public function __construct(PluginBase $plugin) {
        $this->plugin = $plugin;
    }
    public function giveKitAspid(Player $player):void {
        $playerName = $player->getName();
        $currentTime = time();

        if(isset($this->cooldownsKitAspid[$playerName]) && ($currentTime - $this->cooldownsKitAspid[$playerName]) < 172800) {
            $remaining = 172800 - ($currentTime - $this->cooldownsKitAspid[$playerName]);
            $player->sendMessage("Подождите еще " . gmdate("H:i:s", $remaining) . " перед получением набора снова.");
            return;
        }
        $helmet = VanillaItems::DIAMOND_HELMET();
        $chestplate = VanillaItems::DIAMOND_CHESTPLATE();
        $leggings = VanillaItems::DIAMOND_LEGGINGS();
        $boots = VanillaItems::DIAMOND_BOOTS();
        $sword = VanillaItems::DIAMOND_SWORD();
        $gapple = VanillaItems::GOLDEN_APPLE();
        $pearl = VanillaItems::ENDER_PEARL();
        $totem = VanillaItems::TOTEM();
        $pickaxe = VanillaItems::DIAMOND_PICKAXE();
        $axe = VanillaItems::DIAMOND_AXE();
        $shovel = VanillaItems::DIAMOND_SHOVEL();
        $chicken = VanillaItems::COOKED_CHICKEN();
        $exp = VanillaItems::EXPERIENCE_BOTTLE();
        $bow = VanillaItems::BOW();
        $arrow = VanillaItems::ARROW();
    

        $gapple->setCount(3);
        $pearl->setCount(2);
        $chicken->setCount(16);
        $exp->setCount(32);
        $arrow->setCount(16);

        $protection3 = new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3);
        $protection2 = new EnchantmentInstance(VanillaEnchantments::PROTECTION(),2);
        $effectivnost1 = new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(),1);

        $helmet->addEnchantment($protection3);
        $chestplate->addEnchantment($protection3);
        $leggings->addEnchantment($protection2);
        $boots->addEnchantment($protection2);

        $pickaxe->addEnchantment($effectivnost1);
        $axe->addEnchantment($effectivnost1);
        $shovel->addEnchantment($effectivnost1);

        $player->getInventory()->addItem(...[$helmet, $chestplate, $leggings, $boots, $sword, $gapple, $pearl, $totem, $pickaxe, $axe, $shovel, $chicken, $exp, $bow, $arrow]);

        $this->cooldownsKitAspid[$playerName] = $currentTime;

    }
}