<?php

namespace Sasha\Kit\Buttons\KitKnyaz;

use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\item\VanillaItems;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\effect\EffectInstance;

class GiveKitKnyaz {
    private array $cooldownsKitKnyaz = [];
    private PluginBase $plugin;
    
    public function __construct(PluginBase $plugin) {
        $this->plugin = $plugin;
    }

    public function giveKitKnyaz(Player $player): void {
        $playerName = $player->getName();
        $currentTime = time();

       
        if(isset($this->cooldownsKitKnyaz[$playerName]) && ($currentTime - $this->cooldownsKitKnyaz[$playerName]) < 345600) {
            $remaining = 345600 - ($currentTime - $this->cooldownsKitKnyaz[$playerName]);
            $player->sendMessage("Подождите еще " . gmdate("H:i:s", $remaining) . " перед получением набора снова.");
            return;
        }

        
        $helmet = VanillaItems::NETHERITE_HELMET();
        $chestplate = VanillaItems::NETHERITE_CHESTPLATE();
        $leggings = VanillaItems::NETHERITE_LEGGINGS();
        $boots = VanillaItems::NETHERITE_BOOTS();

        
        $sword = VanillaItems::NETHERITE_SWORD();
        $crossbow = VanillaItems::CROSSBOW(); 
        $arrow = VanillaItems::ARROW();

      
        $pickaxe = VanillaItems::NETHERITE_PICKAXE();
        $axe = VanillaItems::NETHERITE_AXE();
        $shovel = VanillaItems::NETHERITE_SHOVEL();

        
        $gapple = VanillaItems::GOLDEN_APPLE();
        $enchantedGapple = VanillaItems::ENCHANTED_GOLDEN_APPLE(); // Чарки
        $pearl = VanillaItems::ENDER_PEARL();
        $totem = VanillaItems::TOTEM();
        $exp = VanillaItems::EXPERIENCE_BOTTLE();
        $exp1 = VanillaItems::EXPERIENCE_BOTTLE();
        $carrot = VanillaItems::GOLDEN_CARROT(); // Золотая морковь
        $shulker = VanillaBlocks::SHULKER_BOX()->asItem(); // Шалкер
        $chorus = VanillaItems::CHORUS_FRUIT(); // Хорус
        $trapdoor = VanillaItems::NETHERITE_SCRAP(); 
        $cobweb = VanillaBlocks::COBWEB()->asItem(); // Паутина (силки)

        // ЗЕЛЬЯ
        $speedPotion = VanillaItems::STRONG_SWIFTNESS_POTION(); // Скорость 2

        
        $gapple->setCount(32);
        $enchantedGapple->setCount(5);
        $pearl->setCount(16);
        $totem->setCount(3);
        $exp->setCount(64);
        $exp1->setCount(64);

        $carrot->setCount(32);
        $arrow->setCount(64);
        $shulker->setCount(2);
        $chorus->setCount(16);
        $trapdoor->setCount(2);
        $cobweb->setCount(6);
        $speedPotion->setCount(6);

        // ЗАЧАРОВАНИЯ БРОНИ (Защита IV на все)
        $protection4 = new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4);
        $unbreaking3 = new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3);

        $helmet->addEnchantment($protection4);
        $helmet->addEnchantment($unbreaking3);
        
        $chestplate->addEnchantment($protection4);
        $chestplate->addEnchantment($unbreaking3);
        
        $leggings->addEnchantment($protection4);
        $leggings->addEnchantment($unbreaking3);
        
        $boots->addEnchantment($protection4);
        $boots->addEnchantment($unbreaking3);

        // ЗАЧАРОВАНИЯ МЕЧА (Острота VI)
        $sharpness6 = new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 6);
        $fireAspect2 = new EnchantmentInstance(VanillaEnchantments::FIRE_ASPECT(), 2);
        
        $sword->addEnchantment($sharpness6);
        $sword->addEnchantment($fireAspect2);

        // ЗАЧАРОВАНИЯ ИНСТРУМЕНТОВ (Эффективность V)
        $efficiency5 = new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 5);
        $unbreaking3 = new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3);
        $fortune3 = new EnchantmentInstance(VanillaEnchantments::FORTUNE(), 3);

        $pickaxe->addEnchantment($efficiency5);
        $pickaxe->addEnchantment($unbreaking3);
        $pickaxe->addEnchantment($fortune3);
        
        $axe->addEnchantment($efficiency5);
        $axe->addEnchantment($unbreaking3);
        
        $shovel->addEnchantment($efficiency5);
        $shovel->addEnchantment($unbreaking3);

        // ЗАЧАРОВАНИЯ АРБАЛЕТА
        $quickCharge3 = new EnchantmentInstance(VanillaEnchantments::QUICK_CHARGE(), 3);
        $piercing4 = new EnchantmentInstance(VanillaEnchantments::PIERCING(), 4);
        $multishot = new EnchantmentInstance(VanillaEnchantments::MULTISHOT(), 1);
        
        $crossbow->addEnchantment($quickCharge3);
        $crossbow->addEnchantment($piercing4);
        $crossbow->addEnchantment($multishot);

        // ВЫДАЧА ПРЕДМЕТОВ
        $player->getInventory()->addItem(
            // Броня
            $helmet, $chestplate, $leggings, $boots,
            // Оружие
            $sword, $crossbow, $arrow,
            // Инструменты
            $pickaxe, $axe, $shovel,
            // Еда и зелья
            $gapple, $enchantedGapple, $carrot, $speedPotion,
            // Телепортация и утилиты
            $pearl, $totem, $exp,
            // Блоки и специальные предметы
            $shulker, $chorus, $trapdoor, $cobweb
        );

        // ОБНОВЛЕНИЕ КУЛДАУНА
        $this->cooldownsKitKnyaz[$playerName] = $currentTime;
        
    }
}