<?php

namespace Sasha\Kit\Buttons\KitKnyaz;

use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use jojoe77777\FormAPI\SimpleForm;

class InfoKitKnyaz {
    private PluginBase $plugin;

    public function __construct(PluginBase $plugin) {
        $this->plugin = $plugin;
    }

    public function infoKitKnyaz(Player $player): void {
        $helmet = VanillaItems::NETHERITE_HELMET();
        $chestplate = VanillaItems::NETHERITE_CHESTPLATE();
        $leggings = VanillaItems::NETHERITE_LEGGINGS();
        $boots = VanillaItems::NETHERITE_BOOTS();

        
        $sword = VanillaItems::NETHERITE_SWORD();
       
        $arrow = VanillaItems::ARROW();

      
        $pickaxe = VanillaItems::NETHERITE_PICKAXE();
        $axe = VanillaItems::NETHERITE_AXE();
        $shovel = VanillaItems::NETHERITE_SHOVEL();

        
        $gapple = VanillaItems::GOLDEN_APPLE();
        $enchantedGapple = VanillaItems::ENCHANTED_GOLDEN_APPLE(); // Чарки
        $pearl = VanillaItems::ENDER_PEARL();
        $totem = VanillaItems::TOTEM();
        $exp = VanillaItems::EXPERIENCE_BOTTLE();
        $exp1 = VanillaItems::EXPERIENCE_BOTTLE();
        $carrot = VanillaItems::GOLDEN_CARROT(); // Золотая морковь
        $shulker = VanillaBlocks::SHULKER_BOX()->asItem(); // Шалкер
        $chorus = VanillaItems::CHORUS_FRUIT(); // Хорус
        $trapa = VanillaItems::NETHERITE_SCRAP(); 
        $cobweb = VanillaBlocks::COBWEB()->asItem(); // Паутина (силки)

        // ЗЕЛЬЯ
        $speedPotion = VanillaItems::POTION();
        $strengPotion = VanillaItems::POTION();
      
      	$speedPotion = $speedPotion->setType(PotionType::STRONG_SWIFTNESS());
        $strengPotion = $strengPotion->setType(PotionType::STRONG_STRENGTH());

        
        $gapple->setCount(32);
        $enchantedGapple->setCount(5);
        $pearl->setCount(16);
        $totem->setCount(3);
        $exp->setCount(64);
        $exp1->setCount(64);

        $carrot->setCount(32);
        $arrow->setCount(64);
        $shulker->setCount(2);
        $chorus->setCount(16);
        $trapa->setCount(2);
        $cobweb->setCount(6);
        $speedPotion->setCount(6);
       	$strengPotion->setCount(6);
      

       
        $protection4 = new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4);
        $unbreaking3 = new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3);

        $helmet->addEnchantment($protection4);
        $helmet->addEnchantment($unbreaking3);
        
        $chestplate->addEnchantment($protection4);
        $chestplate->addEnchantment($unbreaking3);
        
        $leggings->addEnchantment($protection4);
        $leggings->addEnchantment($unbreaking3);
        
        $boots->addEnchantment($protection4);
        $boots->addEnchantment($unbreaking3);

        // ЗАЧАРОВАНИЯ МЕЧА (Острота VI)
        $sharpness6 = new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 6);
        $fireAspect2 = new EnchantmentInstance(VanillaEnchantments::FIRE_ASPECT(), 2);
        
        $sword->addEnchantment($sharpness6);
        $sword->addEnchantment($fireAspect2);

        // ЗАЧАРОВАНИЯ ИНСТРУМЕНТОВ (Эффективность V)
        $efficiency5 = new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 5);
        $unbreaking3 = new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3);
        $fortune3 = new EnchantmentInstance(VanillaEnchantments::FORTUNE(), 3);

        $pickaxe->addEnchantment($efficiency5);
        $pickaxe->addEnchantment($unbreaking3);
        $pickaxe->addEnchantment($fortune3);
        
        $axe->addEnchantment($efficiency5);
        $axe->addEnchantment($unbreaking3);
        
        $shovel->addEnchantment($efficiency5);
        $shovel->addEnchantment($unbreaking3);      
        
       $menu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
       $menu->setName("Содержимое Кит Старта");
       $inventory = $menu->getInventory();
       $inventory->setItem(0, $helmet);
       $inventory->setItem(1, $chestplate);
       $inventory->setItem(3, $sword);
       $inventory->setItem(4, $pickaxe);
       $inventory->setItem(5, $axe);
       $inventory->setItem(6, $shovel);
       $inventory->setItem(8, $totem);
       $inventory->setItem(9, $leggings);
       $inventory->setItem(10, $boots);
       $inventory->setItem(12, $gapple);
       $inventory->setItem(13, $enchantedGapple);
       $inventory->setItem(14, $pearl);
       $inventory->setItem(15, $carrot);
       $inventory->setItem(21, $exp);
       $inventory->setItem(22, $exp1);
       $inventory->setItem(23, $trapa);
       $inventory->setItem(24, $strengPotion);
       $inventory->setItem(25, $speedPotion);
       $inventory->setItem(26, $shulker);

       $glass = VanillaBlocks::STAINED_GLASS_PANE();

       for($i = 0; $i <= 26; $i++) {
            if($inventory->getItem($i)->isNull()) {
                $inventory->setItem($i, $glass);
            }
       }
       $menu->setListener(InvMenu::readonly());
       $menu->send($player);

        
    }
}