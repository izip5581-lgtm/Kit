<?php

namespace Sasha\Kit\Buttons\KitStart;

use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\item\VanillaItems;
use pocketmine\block\VanillaBlocks;


class GiveKitStart {
    private PluginBase $plugin;
    private array $cooldownsKitStart = []; // массив для хранения времени последнего получения

    public function __construct(PluginBase $plugin) {
        $this->plugin = $plugin;
    }

    public function giveKitStart(Player $player):void {
        $playerName = $player->getName();
        $currentTime = time();

        // Проверка кулдауна
        if(isset($this->cooldownsKitStart[$playerName]) && ($currentTime - $this->cooldownsKitStart[$playerName]) < 86400) {
            $remaining = 86400 - ($currentTime - $this->cooldownsKitStart[$playerName]);
            $player->sendMessage("Подождите еще " . gmdate("H:i:s", $remaining) . " перед получением набора снова.");
            return;
        }

        // Выдача предметов
        $sword = VanillaItems::STONE_SWORD();
        $helmet = VanillaItems::LEATHER_CAP();
        $chestplate = VanillaItems::LEATHER_PANTS();
        $leggings = VanillaItems::LEATHER_TUNIC();
        $boots = VanillaItems::LEATHER_BOOTS();
        $pickaxe = VanillaItems::STONE_PICKAXE();
        $torch = VanillaBlocks::TORCH()->asItem();
        $steak = VanillaItems::STEAK();
        $log = VanillaBlocks::OAK_LOG()->asItem();

        $torch->setCount(16);
        $steak->setCount(16);
        $log->setCount(16);

        $player->getInventory()->addItem(...[$sword, $steak, $log, $torch, $pickaxe, $boots, $leggings, $chestplate, $helmet]);

        // Обновление времени последнего получения
        $this->cooldownsKitStart[$playerName] = $currentTime;
    }
}