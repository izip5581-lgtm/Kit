<?php

namespace Sasha\Kit\Buttons\KitStart;

use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use jojoe77777\FormAPI\SimpleForm;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\InvMenuHandler;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\item\VanillaItems;
use pocketmine\block\VanillaBlocks;



class InfoKitStart {
    private PluginBase $plugin;

    public function __construct(PluginBase $plugin) {
        $this->plugin = $plugin;
    }
    

    public function infoKitStart(Player $player): void {
        $sword = VanillaItems::STONE_SWORD();
        $helmet = VanillaItems::LEATHER_CAP();
        $leggings = VanillaItems::LEATHER_PANTS();
        $chestplate = VanillaItems::LEATHER_TUNIC();
        $boots = VanillaItems::LEATHER_BOOTS();
        $pickaxe = VanillaItems::STONE_PICKAXE();
        $torch = VanillaBlocks::TORCH()->asItem();
        $steak = VanillaItems::STEAK();
        $log = VanillaBlocks::OAK_LOG()->asItem();
        $glass = VanillaBlocks::STAINED_GLASS_PANE();

        $torch->setCount(16);
        $steak->setCount(16);
        $log->setCount(16);


       $menu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
       $menu->setName("Содержимое Кит Старта");
       $inventory = $menu->getInventory();
       $inventory->setItem(0, $helmet);
       $inventory->setItem(1, $chestplate);
       $inventory->setItem(9, $leggings);
       $inventory->setItem(10, $boots);
       $inventory->setItem(18, $sword);
       $inventory->setItem(19, $pickaxe);
       $inventory->setItem(3, $torch);
       $inventory->setItem(12, $steak);
       $inventory->setItem(21, $log);
       for($i = 0; $i <= 26; $i++) {
            if($inventory->getItem($i)->isNull()) {
                $inventory->setItem($i, $glass);
            }
       }
       $menu->setListener(InvMenu::readonly());
       $menu->send($player);

    }
}