<?php

namespace Sasha\Kit\Buttons\KitBaron;

use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use jojoe77777\FormAPI\SimpleForm;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\InvMenuHandler;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\item\VanillaItems;
use pocketmine\block\VanillaBlocks;

class InfoBaronKit {
    private PluginBase $plugin;

    public function __construct(PluginBase $plugin) {
        $this->plugin = $plugin;
    }

    public function infoBaronKit(Player $player): void {
        $helmet = VanillaItems::DIAMOND_HELMET();
        $chestplate = VanillaItems::DIAMOND_CHESTPLATE();
        $leggings = VanillaItems::DIAMOND_LEGGINGS();
        $boots = VanillaItems::DIAMOND_BOOTS();
        $sword = VanillaItems::DIAMOND_SWORD();
        $gapple = VanillaItems::GOLDEN_APPLE();
        $pearl = VanillaItems::ENDER_PEARL();
        $totem = VanillaItems::TOTEM();
        $pickaxe = VanillaItems::DIAMOND_PICKAXE();
        $axe = VanillaItems::DIAMOND_AXE();
        $shovel = VanillaItems::DIAMOND_SHOVEL();
        $steak = VanillaItems::STEAK();
    

        $gapple->setCount(3);
        $pearl->setCount(2);
        $steak->setCount(8);

        $protection2 = new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 2);
        $protection1 = new EnchantmentInstance(VanillaEnchantments::PROTECTION(),1);

        $helmet->addEnchantment($protection2);
        $chestplate->addEnchantment($protection2);
        $leggings->addEnchantment($protection1);
        $boots->addEnchantment($protection1);


        $menu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
        $inventory = $menu->getInventory();
        $menu->setName("Содержимое кита барона");
        $inventory->setItem(0, $helmet);
        $inventory->setItem(1, $chestplate);
        $inventory->setItem(2, $sword);
        $inventory->setItem(3, $pickaxe);
        $inventory->setItem(4, $axe);
        $inventory->setItem(5, $shovel);
        $inventory->setItem(9, $leggings);
        $inventory->setItem(10, $boots);
        $inventory->setItem(11, $gapple);
        $inventory->setItem(12, $pearl);
        $inventory->setItem(13, $steak);
        $inventory->setItem(14, $totem);

        $glass = VanillaBlocks::STAINED_GLASS_PANE();
        for($i = 0; $i < 27; $i++) {
            if($inventory->getItem($i)->isNull()) {
                $inventory->setItem($i, $glass);
            }
        }

        $menu->setListener(InvMenu::readonly());
        $menu->send($player);
        
    }
}