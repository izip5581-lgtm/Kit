<?php

namespace Sasha\Kit\Buttons\KitBaron;

use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\item\VanillaItems;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;

class GiveBaronKit {
    private array $cooldownsKitBaron = [];
    private PluginBase $plugin;

    public function __construct(PluginBase $plugin) {
        $this->plugin = $plugin;
    }
    public function giveBaronKit(Player $player):void {
        $playerName = $player->getName();
        $currentTime = time();

        if(isset($this->cooldownsKitBaron[$playerName]) && ($currentTime - $this->cooldownsKitBaron[$playerName])< 86400) {
            $remaining = 86400 -  ($currentTime - $this->cooldownsKitBaron[$playerName]);
            $player->sendMessage("Подождите еще " . gmdate("H:i:s", $remaining) . " перед получением набора снова.");
            return;
        }
        $helmet = VanillaItems::DIAMOND_HELMET();
        $chestplate = VanillaItems::DIAMOND_CHESTPLATE();
        $leggings = VanillaItems::DIAMOND_LEGGINGS();
        $boots = VanillaItems::DIAMOND_BOOTS();
        $sword = VanillaItems::DIAMOND_SWORD();
        $gapple = VanillaItems::GOLDEN_APPLE();
        $pearl = VanillaItems::ENDER_PEARL();
        $totem = VanillaItems::TOTEM();
        $pickaxe = VanillaItems::DIAMOND_PICKAXE();
        $axe = VanillaItems::DIAMOND_AXE();
        $shovel = VanillaItems::DIAMOND_SHOVEL();
        $steak = VanillaItems::STEAK();
    

        $gapple->setCount(3);
        $pearl->setCount(2);
        $steak->setCount(8);

        $protection2 = new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 2);
        $protection1 = new EnchantmentInstance(VanillaEnchantments::PROTECTION(),1);

        $helmet->addEnchantment($protection2);
        $chestplate->addEnchantment($protection2);
        $leggings->addEnchantment($protection1);
        $boots->addEnchantment($protection1);

        $player->getInventory()->addItem(...[$helmet, $chestplate, $leggings, $boots, $sword, $gapple,$pearl,$totem,$pickaxe,$axe,$shovel,$steak]);

        $this->cooldownsKitBaron[$playerName] = $currentTime;
    }
}